---Instruction---
1. Download the archive.
2. Unzip the archive.
3. Run the "exe" files as administrator.





p.s: If anitivirus blocks the file, you should disable it during installation or add setup.exe to the white list